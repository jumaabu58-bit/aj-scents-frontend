import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CircleCheck, i as Minus, r as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DeNipSxf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var products = [
	{
		id: 1,
		name: "Noir Elegance",
		category: "perfume",
		price: 185e3,
		image: "/products/perfume-1.jpg"
	},
	{
		id: 2,
		name: "Rose Whisper",
		category: "perfume",
		price: 165e3,
		image: "/products/perfume-2.jpg"
	},
	{
		id: 3,
		name: "Ocean Breeze",
		category: "perfume",
		price: 145e3,
		image: "/products/perfume-3.jpg"
	},
	{
		id: 4,
		name: "Golden Oud",
		category: "perfume",
		price: 245e3,
		image: "/products/perfume-4.jpg"
	},
	{
		id: 5,
		name: "Premium Leather Shoe 1",
		category: "shoes",
		price: 28e4,
		image: "/products/shoe-1.jpg"
	},
	{
		id: 6,
		name: "Premium Leather Shoe 2",
		category: "shoes",
		price: 295e3,
		image: "/products/shoe-2.jpg"
	},
	{
		id: 7,
		name: "Premium Leather Shoe 3",
		category: "shoes",
		price: 31e4,
		image: "/products/shoe-3.jpg"
	},
	{
		id: 8,
		name: "Premium Leather Shoe 4",
		category: "shoes",
		price: 275e3,
		image: "/products/shoe-4.jpg"
	},
	{
		id: 9,
		name: "Classic Backpack",
		category: "bags",
		price: 185e3,
		image: "/products/bag-1.jpg"
	},
	{
		id: 10,
		name: "Designer Backpack",
		category: "bags",
		price: 21e4,
		image: "/products/bag-2.jpg"
	},
	{
		id: 11,
		name: "Urban Backpack",
		category: "bags",
		price: 195e3,
		image: "/products/bag-3.jpg"
	},
	{
		id: 12,
		name: "Leather Style Bag",
		category: "bags",
		price: 225e3,
		image: "/products/bag-4.jpg"
	},
	{
		id: 13,
		name: "Travel Backpack",
		category: "bags",
		price: 24e4,
		image: "/products/bag-5.jpg"
	},
	{
		id: 14,
		name: "Casual Backpack",
		category: "bags",
		price: 175e3,
		image: "/products/bag-6.jpg"
	},
	{
		id: 15,
		name: "Premium Backpack",
		category: "bags",
		price: 255e3,
		image: "/products/bag-10.jpg"
	},
	{
		id: 16,
		name: "Stylish Backpack",
		category: "bags",
		price: 19e4,
		image: "/products/bag-8.jpg"
	},
	{
		id: 17,
		name: "Modern Backpack",
		category: "bags",
		price: 205e3,
		image: "/products/bag-11.jpg"
	},
	{
		id: 18,
		name: "Executive Bag",
		category: "bags",
		price: 265e3,
		image: "/products/bag-7.jpg"
	},
	{
		id: 19,
		name: "City Backpack",
		category: "bags",
		price: 18e4,
		image: "/products/bag-9.jpg"
	},
	{
		id: 20,
		name: "Luxury Backpack",
		category: "bags",
		price: 275e3,
		image: "/products/bag-2.jpg"
	},
	{
		id: 21,
		name: "Everyday Backpack",
		category: "bags",
		price: 165e3,
		image: "/products/bag-6.jpg"
	}
];
var WHATSAPP = "256705127282";
function formatUgx(amount) {
	return `UGX ${amount.toLocaleString("en-UG")}`;
}
var filters = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "perfume",
		label: "Perfumes"
	},
	{
		id: "shoes",
		label: "Shoes"
	},
	{
		id: "bags",
		label: "Bags"
	}
];
function Home() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [cart, setCart] = (0, import_react.useState)([]);
	const [cartOpen, setCartOpen] = (0, import_react.useState)(false);
	const [checkoutOpen, setCheckoutOpen] = (0, import_react.useState)(false);
	const [ordered, setOrdered] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const visible = (0, import_react.useMemo)(() => filter === "all" ? products : products.filter((p) => p.category === filter), [filter]);
	const count = cart.reduce((sum, item) => sum + item.quantity, 0);
	const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
	function addToCart(product) {
		setCart((prev) => {
			if (!prev.find((item) => item.id === product.id)) return [...prev, {
				...product,
				quantity: 1
			}];
			return prev.map((item) => item.id === product.id ? {
				...item,
				quantity: item.quantity + 1
			} : item);
		});
		toast.success(`${product.name} added to cart`);
	}
	function changeQty(id, delta) {
		setCart((prev) => prev.map((item) => item.id === id ? {
			...item,
			quantity: item.quantity + delta
		} : item).filter((item) => item.quantity > 0));
	}
	function openCheckout() {
		if (cart.length === 0) {
			toast.error("Your cart is empty");
			return;
		}
		setOrdered(false);
		setCartOpen(false);
		setCheckoutOpen(true);
	}
	function placeOrder() {
		if (!name.trim() || !phone.trim() || !address.trim()) {
			toast.error("Please fill in name, phone and address");
			return;
		}
		const lines = cart.map((item) => `- ${item.name} × ${item.quantity} = ${formatUgx(item.price * item.quantity)}`).join("\n");
		const message = [
			"Hello AJ Scents & More,",
			"",
			"New Order",
			"",
			`Name: ${name.trim()}`,
			`Phone: ${phone.trim()}`,
			`Address: ${address.trim()}`,
			"",
			"Items:",
			lines,
			"",
			`Total: ${formatUgx(total)}`,
			"",
			"Please confirm my order."
		].join("\n");
		window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
		setCart([]);
		setOrdered(true);
		setName("");
		setPhone("");
		setAddress("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "light",
				position: "top-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between px-5 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-xs tracking-[0.22em] text-brass uppercase sm:block",
							children: "Kampala"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "font-display text-2xl tracking-tight text-fg",
							children: [
								"AJ Scents ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-accent",
									children: "&"
								}),
								" More"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setCartOpen(true),
							className: "relative flex min-h-11 items-center gap-2 text-sm",
							"aria-label": "Open cart",
							children: ["Bag", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-6 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-ink",
								children: count
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto grid max-w-6xl items-end gap-8 px-5 pt-10 pb-6 lg:grid-cols-[1.15fr_0.85fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-[0.28em] text-brass uppercase",
								children: "House collection"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display mt-4 max-w-xl text-5xl leading-[0.95] text-fg sm:text-7xl",
								children: "Scent, leather, and the bag you keep."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-md text-lg text-muted",
								children: "Perfumes, shoes and bags from Kampala. Choose a piece, then send the order on WhatsApp."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#shop",
								className: "mt-8 inline-flex min-h-11 items-center border-b-2 border-accent pb-1 font-medium text-accent",
								children: "Browse the house"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: products[4].image,
							alt: products[4].name,
							className: "aspect-[4/5] w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "mt-2 flex justify-between text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: products[4].name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shoes" })]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mx-auto grid max-w-6xl gap-3 px-5 pb-12 sm:grid-cols-3",
						children: [
							{
								label: "Perfumes",
								id: "perfume",
								image: products[0].image
							},
							{
								label: "Shoes",
								id: "shoes",
								image: products[6].image
							},
							{
								label: "Bags",
								id: "bags",
								image: products[8].image
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setFilter(item.id);
								document.getElementById("shop")?.scrollIntoView({ behavior: "smooth" });
							},
							className: "group relative h-40 overflow-hidden text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.image,
									alt: "",
									className: "h-full w-full object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-fg/35" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display absolute bottom-3 left-4 text-3xl text-accent-ink",
									children: item.label
								})
							]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "shop",
						className: "mx-auto max-w-6xl px-5 py-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 border-t border-line pt-8 sm:flex-row sm:items-end sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl text-fg",
								children: "The edit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: filters.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setFilter(item.id),
									className: `min-h-11 px-3 text-sm ${filter === item.id ? "border-b-2 border-accent font-semibold text-accent" : "text-muted"}`,
									children: item.label
								}, item.id))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid grid-cols-1 gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3",
							children: visible.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: product.image,
									alt: product.name,
									className: "aspect-[3/4] w-full bg-surface-2 object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl leading-none",
										children: product.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "shrink-0 text-sm",
										children: formatUgx(product.price)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted capitalize",
									children: product.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => addToCart(product),
									className: "mt-3 min-h-11 text-sm font-medium tracking-wide text-accent uppercase",
									children: "Add to bag"
								})
							] }, product.id))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mx-auto flex max-w-6xl flex-col gap-2 border-t border-line px-5 py-10 text-sm text-muted sm:flex-row sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "AJ Scents & More · Kampala" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Perfumes, shoes and bags · WhatsApp orders" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: `https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hello AJ Scents & More, I would like to inquire about your products.")}`,
				target: "_blank",
				rel: "noopener noreferrer",
				className: "fixed right-4 bottom-4 z-30 flex size-14 items-center justify-center rounded-full bg-whatsapp text-accent-ink shadow-lg",
				"aria-label": "Chat on WhatsApp",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageIcon, {})
			}),
			cartOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-40 bg-fg/40",
				"aria-label": "Close cart",
				onClick: () => setCartOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `fixed top-0 right-0 z-50 flex h-full w-full max-w-md flex-col bg-surface p-5 transition-transform duration-200 ${cartOpen ? "translate-x-0" : "translate-x-full"}`,
				"aria-hidden": !cartOpen,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl",
							children: "Your bag"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCartOpen(false),
							"aria-label": "Close cart",
							className: "p-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex-1 overflow-y-auto",
						children: cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-16 text-center text-muted",
							children: "Your bag is empty"
						}) : cart.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 border-b border-line py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.image,
								alt: "",
								className: "size-16 object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "truncate font-medium",
										children: item.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: formatUgx(item.price)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "flex size-9 items-center justify-center border border-line",
												onClick: () => changeQty(item.id, -1),
												"aria-label": `Decrease ${item.name}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-6 text-center",
												children: item.quantity
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "flex size-9 items-center justify-center border border-line",
												onClick: () => changeQty(item.id, 1),
												"aria-label": `Increase ${item.name}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
											})
										]
									})
								]
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-3 text-xl",
								children: ["Total ", formatUgx(total)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: openCheckout,
								className: "min-h-11 w-full bg-accent font-medium text-accent-ink",
								children: "Checkout"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCartOpen(false),
								className: "mt-2 min-h-11 w-full border border-line",
								children: "Keep browsing"
							})
						]
					})
				]
			}),
			checkoutOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-fg/45 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[92vh] w-full max-w-md overflow-y-auto bg-surface p-5",
					children: ordered ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-8 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-14 text-whatsapp" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display mt-4 text-4xl",
								children: "Order ready"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: "WhatsApp should be open. We will confirm your order there."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCheckoutOpen(false),
								className: "mt-6 min-h-11 bg-accent px-6 font-medium text-accent-ink",
								children: "Back to the edit"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl",
								children: "Checkout"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCheckoutOpen(false),
								"aria-label": "Close checkout",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-sm text-muted",
							children: ["Full name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (e) => setName(e.target.value),
								className: "mt-1 min-h-11 w-full border border-line bg-bg px-3 text-fg",
								placeholder: "Your name"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm text-muted",
							children: ["Phone number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								className: "mt-1 min-h-11 w-full border border-line bg-bg px-3 text-fg",
								placeholder: "07XXXXXXXX",
								inputMode: "tel"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 block text-sm text-muted",
							children: ["Delivery address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: address,
								onChange: (e) => setAddress(e.target.value),
								className: "mt-1 min-h-20 w-full border border-line bg-bg px-3 py-2 text-fg",
								placeholder: "Street, area, city"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 bg-bg p-3 text-sm",
							children: [cart.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-3 py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									item.name,
									" × ",
									item.quantity
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatUgx(item.price * item.quantity) })]
							}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-between border-t border-line pt-2 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatUgx(total) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: placeOrder,
							className: "mt-4 flex min-h-11 w-full items-center justify-center gap-2 bg-whatsapp font-medium text-accent-ink",
							children: "Complete order on WhatsApp"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCheckoutOpen(false),
							className: "mt-2 min-h-11 w-full border border-line",
							children: "Cancel"
						})
					] })
				})
			})
		]
	});
}
function MessageIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-7 fill-current",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.5 3.5A11 11 0 0 0 2.1 16.7L1 23l6.5-1.1A11 11 0 0 0 20.5 3.5ZM12 20.2a9.1 9.1 0 0 1-4.6-1.3l-.3-.2-3.9.7.7-3.8-.2-.3A9.2 9.2 0 1 1 12 20.2Zm5-6.9c-.3-.1-1.6-.8-1.8-.9s-.4-.1-.6.2-.7.9-.8 1-.3.2-.6.1a7.5 7.5 0 0 1-2.2-1.4 8.2 8.2 0 0 1-1.5-1.9c-.2-.3 0-.4.1-.6l.4-.5.2-.3a.5.5 0 0 0 0-.5c0-.1-.6-1.4-.8-1.9s-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.8 11.8 0 0 0 4.5 4 15 15 0 0 0 1.5.6 3.6 3.6 0 0 0 1.7.1 2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.6-.3Z" })
	});
}
//#endregion
export { Home as component };
