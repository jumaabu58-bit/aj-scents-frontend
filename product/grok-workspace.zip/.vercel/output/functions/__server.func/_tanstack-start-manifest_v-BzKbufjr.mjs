//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BzKbufjr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-RbfU-4g8.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-RbfU-4g8.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bt0y9PyH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
